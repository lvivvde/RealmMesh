#include "startup_topology.hpp"
#include <filesystem>
void observe_public_topology_loader() {
    static_cast<void>(realm::service_host::load_topology(std::filesystem::path(".")));
}
