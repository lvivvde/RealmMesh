# Linux Login Chain M1–M4 acceptance

- Started: 2026-10-13T16:18:14Z
- Platform: Ubuntu 24.04.5 LTS; kernel 6.17.0-1022-azure; x86_64
- CPU: 4 logical; AMD EPYC 7763 64-Core Processor
- Memory: 16373452 KiB
- File-descriptor limit: 65536
- Revision: `4712ffdf56ce9101757f1225b012e709fd128e8d` (clean working tree)
- Build: preset `dev`; directory `/home/runner/work/RealmMesh/RealmMesh/build/dev-ninja`
- Topology: one Linux host; production service/loadgen paths in the dev-preset build; four independent service processes where required; temporary real etcd
- Transport: real MsQuic server/client exchange plus production Login Chain TLS/TCP fallback
- Repetitions: transport/M1/M2=3; M3/M4=1
- Raw log: `linux-login-chain-m1-m4.log`

## Command

`REALMMESH_ACCEPTANCE_REPEATS=3 REALMMESH_LINUX_ACCEPTANCE_SKIP_BUILD=1 ./scripts/run-linux-login-acceptance.sh --preset dev`

## Acceptance levels

| Level | CI-scale input and gate | Production target from #32 |
|---|---|---|
| Transport | real QUIC verified stream; TLS/TCP staged fallback; certificate failure must not fall back | both Gateway and Realm candidate paths |
| M1 | 100 Gateway sessions for 5s; concurrent multi-stage water; attach P99 <=5x same-load baseline; no fd growth | 100k mixed sessions for 30 min; <=3 GB; no P99 drift/fd/OOM |
| M2 | 250 robots/64 concurrency/25s; >=248 complete; fetch failures <1% | 100k robots handed off in 60s |
| M3 | 10k durable tickets + 2k progress clients; >=99.9% success | 1m tickets; origin <=5k QPS; cache hit >=99% |
| M4 | Gateway/Realm budget-key convergence <=10s; Queue cold recovery <=30s; released number monotonic; no Grant replay | same gates on staged topology |

> The CI profile is a deterministic regression baseline. It reports, but does not claim, the dedicated-host 100k/1m capacity targets. M5 remains out of scope.

## Source configuration

```text
badf4cc0e32b5da4a7c84da777978704f2a37ff71b021332ae2f16b3e94bcfbb  configs/main.config
c2a7f81fc5fbe8598978ad82f0b7fef37f3325d21813bdb889c06a2f0e3d6eb7  configs/common/discovery.lua
f34f4b853456c2fbab99c51a12cd2e9428bb31cfb76b93d8ad9d370026101068  configs/common/player_data.lua
9219d59f3fc2b25daab02b01a575dcd942e79f2c39821931384b29177a91d8b4  configs/services/login_verify.lua
8b1bf0b7741e3b2edf320c601662a9419ad8a1079a0f2963e0605f783044e559  configs/services/queue.lua
4be72b8bbec6b7c58dcff27cac3f673b5f9366ad85f5ce806b4a5008d8cbd371  configs/services/gateway.lua
d2096415e096a6fa731d4b533473af9f8071fac66c98304e9f77b96e84c773ac  configs/services/realm.lua
f5d7d56f439a65029b9b2b9a54f3a6a85723feaadda9c8b1810e49205b3f7ba0  .github/workflows/ci.yml
```

## Results

| Group | Runs | Elapsed | Result |
|---|---:|---:|---|
| Transport and topology | 3 | 14s | PASS |
| M1 directed soak | 3 | 59s | PASS |
| M2 admission and durable issuance | 3 | 38s | PASS |
| M3 ticket and progress load | 1 | 62s | PASS |
| M4 failure and recovery | 1 | 65s | PASS |

## Measured evidence

```text
16: acceptance_runtime login_verify=127.0.0.1:21881 queue=127.0.0.1:25488 gateway=127.0.0.1:23415 realm=127.0.0.1:28446 etcd=http://127.0.0.1:22845 mongodb=127.0.0.1:47969
16: acceptance_runtime_config badf4cc0e32b5da4a7c84da777978704f2a37ff71b021332ae2f16b3e94bcfbb  configs/main.config
16: acceptance_runtime_config a8dfd0d0eef2dfdffa0771609326a7cadbf5f685618470e504f58a10046bda17  configs/common/discovery.lua
16: acceptance_runtime_config 69b5c275f09cbca512ae487c308a2b07accc71404e48b11c3dd5973212203b63  configs/common/accounts.lua
16: acceptance_runtime_config 9d2120f4ff2d981bc94997fc30e845b214468180ace1d8a3a4dfc7e37e127b4b  configs/common/player_data.lua
16: acceptance_runtime_config d8ae3a2ae3644d5322ad9b473c15edbde47dbf3d1887addede659161fabf70d6  configs/services/login_verify.lua
16: acceptance_runtime_config c50d318bf421ead3bc07109b942c5eee51760d1e3325b235f715917415616210  configs/services/queue.lua
16: acceptance_runtime_config 04484ff2ab5351592cd58c1ac30e8de8c3cd0ae45f14fde89831926dde3abe14  configs/services/gateway.lua
16: acceptance_runtime_config ef1287026c61aa1ad04171a1d15bd2be35e584a117283d735652d4d84f22d54d  configs/services/realm.lua
16: loadgen report
16: robots: 1  completed: 1
16: verify: attempts=1 failures=0 p50_ms=176.542660 p99_ms=176.542660 max_ms=176.542660
16: tickets: attempts=1 failures=0 p50_ms=150.152930 p99_ms=150.152930 max_ms=150.152930
16: poll: attempts=28 failures=0 p50_ms=0.231552 p99_ms=48.491723 max_ms=48.491723
16: attach: attempts=1 failures=0 p50_ms=46.048790 p99_ms=46.048790 max_ms=46.048790
16: handoff: attempts=1 failures=0 p50_ms=96.283798 p99_ms=96.283798 max_ms=96.283798
16: realm: attempts=1 failures=0 p50_ms=47.947693 p99_ms=47.947693 max_ms=47.947693
16: acceptance_runtime login_verify=127.0.0.1:23212 queue=127.0.0.1:25079 gateway=127.0.0.1:23277 realm=127.0.0.1:22065 etcd=http://127.0.0.1:28315 mongodb=127.0.0.1:47969
16: acceptance_runtime_config badf4cc0e32b5da4a7c84da777978704f2a37ff71b021332ae2f16b3e94bcfbb  configs/main.config
16: acceptance_runtime_config 28fb37e9ae00bb0beb3c9af9d69d6ed4fef52e9927f502978488cfa435dd93a8  configs/common/discovery.lua
16: acceptance_runtime_config 69b5c275f09cbca512ae487c308a2b07accc71404e48b11c3dd5973212203b63  configs/common/accounts.lua
16: acceptance_runtime_config b540eecab3d4fdd94a30f86f365bb43972702cfae13e31ed2c929c90f66e3b83  configs/common/player_data.lua
16: acceptance_runtime_config e7afb986c939b3bc5c8e4667572c8cb95cddb1f6849612d17d5ffdadf5625622  configs/services/login_verify.lua
16: acceptance_runtime_config 937dba692a61cdbee9a7e16536b0321c84b8632501bd9c6227944517432ce257  configs/services/queue.lua
16: acceptance_runtime_config 07cac30449f43e7f2fea8218f025f5f640d05408b4e53ebc8adb55e79f9f639c  configs/services/gateway.lua
16: acceptance_runtime_config 1767378f0aa560af89f052d68cb5b52f83879af1f6ae56aec013c9114d4ebb96  configs/services/realm.lua
16: loadgen report
16: robots: 1  completed: 1
16: verify: attempts=1 failures=0 p50_ms=178.513280 p99_ms=178.513280 max_ms=178.513280
16: tickets: attempts=1 failures=0 p50_ms=153.296627 p99_ms=153.296627 max_ms=153.296627
16: poll: attempts=28 failures=0 p50_ms=0.283739 p99_ms=48.251947 max_ms=48.251947
16: attach: attempts=1 failures=0 p50_ms=41.475087 p99_ms=41.475087 max_ms=41.475087
16: handoff: attempts=1 failures=0 p50_ms=74.312050 p99_ms=74.312050 max_ms=74.312050
16: realm: attempts=1 failures=0 p50_ms=42.566752 p99_ms=42.566752 max_ms=42.566752
16: acceptance_runtime login_verify=127.0.0.1:28782 queue=127.0.0.1:24882 gateway=127.0.0.1:26567 realm=127.0.0.1:29993 etcd=http://127.0.0.1:26572 mongodb=127.0.0.1:47969
16: acceptance_runtime_config badf4cc0e32b5da4a7c84da777978704f2a37ff71b021332ae2f16b3e94bcfbb  configs/main.config
16: acceptance_runtime_config e9346f629837cbbd61c586fbae4f4153852a94870aac00774a34bd1068a00d22  configs/common/discovery.lua
16: acceptance_runtime_config 69b5c275f09cbca512ae487c308a2b07accc71404e48b11c3dd5973212203b63  configs/common/accounts.lua
16: acceptance_runtime_config 1f847a253b7db1dc6dd96c33e0e4b1da5893055d33db5585492572883f48f0a1  configs/common/player_data.lua
16: acceptance_runtime_config aa1d9a39ce9fb9807c0e051583171df0f2b4210f63ed9386626de8992218c622  configs/services/login_verify.lua
16: acceptance_runtime_config b2e3e5dc6d4727fbc8ea5c59ee7e18bde02ec71c83b832383e849b299ca16aea  configs/services/queue.lua
16: acceptance_runtime_config f890db217e42e9f0ba3ae4a09b577ce0a0d7cf093ebaeb7dc2b5aaae1acb37e7  configs/services/gateway.lua
16: acceptance_runtime_config 614218d82e3eb7e389dff196ef5150a43a5ddf79ff34047ab0f95a9f48a1a4c6  configs/services/realm.lua
16: loadgen report
16: robots: 1  completed: 1
16: verify: attempts=1 failures=0 p50_ms=179.629422 p99_ms=179.629422 max_ms=179.629422
16: tickets: attempts=1 failures=0 p50_ms=149.583305 p99_ms=149.583305 max_ms=149.583305
16: poll: attempts=28 failures=0 p50_ms=0.259624 p99_ms=48.169527 max_ms=48.169527
16: attach: attempts=1 failures=0 p50_ms=46.319234 p99_ms=46.319234 max_ms=46.319234
16: handoff: attempts=1 failures=0 p50_ms=96.458682 p99_ms=96.458682 max_ms=96.458682
16: realm: attempts=1 failures=0 p50_ms=42.485214 p99_ms=42.485214 max_ms=42.485214
662: acceptance_m1 gateway_soak completed=100 attach_failures=0 handoff_failures=0 capacity=20000 max_pending=0 max_fetching=64 max_handed_off=100 mixed_water_sample=1 water_samples=600 baseline_attach_p50_ms=326.472 main_attach_p50_ms=340.887 baseline_attach_p99_ms=367.335 main_attach_p99_ms=388.604 fd_before=48 fd_after=48
662: acceptance_m1 gateway_soak completed=100 attach_failures=0 handoff_failures=0 capacity=20000 max_pending=0 max_fetching=64 max_handed_off=100 mixed_water_sample=1 water_samples=592 baseline_attach_p50_ms=329.625 main_attach_p50_ms=348.032 baseline_attach_p99_ms=516.398 main_attach_p99_ms=409.303 fd_before=48 fd_after=48
662: acceptance_m1 gateway_soak completed=100 attach_failures=0 handoff_failures=0 capacity=20000 max_pending=0 max_fetching=81 max_handed_off=100 mixed_water_sample=1 water_samples=606 baseline_attach_p50_ms=331.116 main_attach_p50_ms=393.111 baseline_attach_p99_ms=382.829 main_attach_p99_ms=478.184 fd_before=48 fd_after=48
664: loadgen report
664: robots: 1  completed: 1
664: verify: attempts=1 failures=0 p50_ms=51.205290 p99_ms=51.205290 max_ms=51.205290
664: tickets: attempts=1 failures=0 p50_ms=52.996320 p99_ms=52.996320 max_ms=52.996320
664: poll: attempts=39 failures=0 p50_ms=0.232765 p99_ms=6.241234 max_ms=6.241234
664: attach: attempts=1 failures=0 p50_ms=41.610699 p99_ms=41.610699 max_ms=41.610699
664: handoff: attempts=1 failures=0 p50_ms=0.040516 p99_ms=0.040516 max_ms=0.040516
664: realm: attempts=1 failures=0 p50_ms=42.883084 p99_ms=42.883084 max_ms=42.883084
664: loadgen report
664: robots: 1  completed: 1
664: verify: attempts=1 failures=0 p50_ms=50.995034 p99_ms=50.995034 max_ms=50.995034
664: tickets: attempts=1 failures=0 p50_ms=52.947046 p99_ms=52.947046 max_ms=52.947046
664: poll: attempts=39 failures=0 p50_ms=0.278570 p99_ms=4.688000 max_ms=4.688000
664: attach: attempts=1 failures=0 p50_ms=40.782561 p99_ms=40.782561 max_ms=40.782561
664: handoff: attempts=1 failures=0 p50_ms=0.044704 p99_ms=0.044704 max_ms=0.044704
664: realm: attempts=1 failures=0 p50_ms=42.861549 p99_ms=42.861549 max_ms=42.861549
664: loadgen report
664: robots: 1  completed: 1
664: verify: attempts=1 failures=0 p50_ms=51.681177 p99_ms=51.681177 max_ms=51.681177
664: tickets: attempts=1 failures=0 p50_ms=52.997311 p99_ms=52.997311 max_ms=52.997311
664: poll: attempts=39 failures=0 p50_ms=0.237043 p99_ms=4.671225 max_ms=4.671225
664: attach: attempts=1 failures=0 p50_ms=40.782725 p99_ms=40.782725 max_ms=40.782725
664: handoff: attempts=1 failures=0 p50_ms=0.049352 p99_ms=0.049352 max_ms=0.049352
664: realm: attempts=1 failures=0 p50_ms=42.831111 p99_ms=42.831111 max_ms=42.831111
666: acceptance_m2 robots=250 completed=250 skipped=0 attach_attempts=250 attach_failures=0 handoff_attempts=250 handoff_failures=0 fetch_count=250 fetch_retries=0 fetch_failure_rate=0
666: acceptance_m2 robots=250 completed=250 skipped=0 attach_attempts=250 attach_failures=0 handoff_attempts=250 handoff_failures=0 fetch_count=250 fetch_retries=0 fetch_failure_rate=0
666: acceptance_m2 robots=250 completed=250 skipped=0 attach_attempts=250 attach_failures=0 handoff_attempts=250 handoff_failures=0 fetch_count=250 fetch_retries=0 fetch_failure_rate=0
599: queue issuance write load: 854.136 committed numbers/s
599: queue issuance write load: 858.938 committed numbers/s
599: queue issuance write load: 856.749 committed numbers/s
667: acceptance_m3 tickets_robots=10000 tickets_completed=10000 tickets_skipped=0 poll_robots=2000 poll_completed=2000 poll_skipped=0 poll_attempts=20532
17: acceptance_fault gateway_budget_removal elapsed_s=6 threshold_s=10 result=PASS
17: loadgen report
17: robots: 1  completed: 0
17: verify: attempts=1 failures=0 p50_ms=197.390706 p99_ms=197.390706 max_ms=197.390706
17: tickets: attempts=1 failures=0 p50_ms=146.505004 p99_ms=146.505004 max_ms=146.505004
17: poll: attempts=8 failures=0 p50_ms=0.196527 p99_ms=48.365173 max_ms=48.365173
17: attach: attempts=43 failures=43 p50_ms=0.000000 p99_ms=0.000000 max_ms=0.000000
17: loadgen report
17: robots: 1  completed: 1
17: verify: attempts=1 failures=0 p50_ms=162.276973 p99_ms=162.276973 max_ms=162.276973
17: tickets: attempts=1 failures=0 p50_ms=146.486741 p99_ms=146.486741 max_ms=146.486741
17: poll: attempts=43 failures=0 p50_ms=0.191688 p99_ms=48.426189 max_ms=48.426189
17: attach: attempts=1 failures=0 p50_ms=48.217027 p99_ms=48.217027 max_ms=48.217027
17: handoff: attempts=1 failures=0 p50_ms=96.417978 p99_ms=96.417978 max_ms=96.417978
17: realm: attempts=1 failures=0 p50_ms=49.804731 p99_ms=49.804731 max_ms=49.804731
17: acceptance_fault gateway_budget_restore elapsed_s=3 threshold_s=10 result=PASS
17: acceptance_fault realm_budget_removal elapsed_s=0 threshold_s=10 result=PASS
17: loadgen report
17: robots: 1  completed: 0
17: verify: attempts=1 failures=0 p50_ms=177.111755 p99_ms=177.111755 max_ms=177.111755
17: tickets: attempts=1 failures=0 p50_ms=146.509803 p99_ms=146.509803 max_ms=146.509803
17: poll: attempts=141 failures=3 p50_ms=0.193030 p99_ms=48.095480 max_ms=48.147647
17: loadgen report
17: robots: 1  completed: 1
17: verify: attempts=1 failures=0 p50_ms=185.997860 p99_ms=185.997860 max_ms=185.997860
17: tickets: attempts=1 failures=0 p50_ms=146.497366 p99_ms=146.497366 max_ms=146.497366
17: poll: attempts=17 failures=0 p50_ms=0.165058 p99_ms=48.612635 max_ms=48.612635
17: attach: attempts=1 failures=0 p50_ms=48.023242 p99_ms=48.023242 max_ms=48.023242
17: handoff: attempts=1 failures=0 p50_ms=96.234455 p99_ms=96.234455 max_ms=96.234455
17: realm: attempts=1 failures=0 p50_ms=47.701462 p99_ms=47.701462 max_ms=47.701462
17: acceptance_fault realm_budget_restore elapsed_s=2 threshold_s=10 result=PASS
17: loadgen report
17: robots: 1  completed: 1
17: verify: attempts=1 failures=0 p50_ms=150.839898 p99_ms=150.839898 max_ms=150.839898
17: tickets: attempts=1 failures=0 p50_ms=147.689828 p99_ms=147.689828 max_ms=147.689828
17: poll: attempts=19 failures=0 p50_ms=0.232484 p99_ms=49.387948 max_ms=49.387948
17: attach: attempts=1 failures=0 p50_ms=48.034384 p99_ms=48.034384 max_ms=48.034384
17: handoff: attempts=1 failures=0 p50_ms=96.376770 p99_ms=96.376770 max_ms=96.376770
17: realm: attempts=1 failures=0 p50_ms=47.748875 p99_ms=47.748875 max_ms=47.748875
17: acceptance_fault queue_released_number before=5 after=5 result=PASS
17: loadgen report
17: robots: 1  completed: 1
17: verify: attempts=1 failures=0 p50_ms=171.729796 p99_ms=171.729796 max_ms=171.729796
17: tickets: attempts=1 failures=0 p50_ms=160.704547 p99_ms=160.704547 max_ms=160.704547
17: poll: attempts=31 failures=0 p50_ms=0.195368 p99_ms=49.003028 max_ms=49.003028
17: attach: attempts=1 failures=0 p50_ms=40.777926 p99_ms=40.777926 max_ms=40.777926
17: handoff: attempts=1 failures=0 p50_ms=91.577419 p99_ms=91.577419 max_ms=91.577419
17: realm: attempts=1 failures=0 p50_ms=45.571947 p99_ms=45.571947 max_ms=45.571947
17: acceptance_fault queue_cold_restart elapsed_s=8 threshold_s=30 result=PASS
17: acceptance_fault etcd_outage_unready elapsed_s=1 threshold_s=10 result=PASS
17: loadgen report
17: robots: 1  completed: 0
17: verify: attempts=1 failures=0 p50_ms=154.424132 p99_ms=154.424132 max_ms=154.424132
17: tickets: attempts=1 failures=1 p50_ms=4683.731752 p99_ms=4683.731752 max_ms=4683.731752
17: acceptance_fault etcd_recovery elapsed_s=0 threshold_s=10 result=PASS
17: loadgen report
17: robots: 1  completed: 1
17: verify: attempts=1 failures=0 p50_ms=193.941373 p99_ms=193.941373 max_ms=193.941373
17: tickets: attempts=1 failures=0 p50_ms=142.733939 p99_ms=142.733939 max_ms=142.733939
17: poll: attempts=30 failures=0 p50_ms=0.279081 p99_ms=49.593238 max_ms=49.593238
17: attach: attempts=1 failures=0 p50_ms=52.409469 p99_ms=52.409469 max_ms=52.409469
17: handoff: attempts=1 failures=0 p50_ms=98.470798 p99_ms=98.470798 max_ms=98.470798
17: realm: attempts=1 failures=0 p50_ms=45.782450 p99_ms=45.782450 max_ms=45.782450
17: acceptance_fault queue_authoritative_recovery elapsed_s=3 threshold_s=30 result=PASS
```

## Limitations

- CI runs on one GitHub-hosted Ubuntu 24.04 machine; it does not prove cross-machine network or etcd TLS/authentication behavior.
- Accounts and characters come from MongoDB Player Data (ADR-0011): each case starts its own single-node `rs0` replica set on the runner, and Login Verifier authenticates, Gateway fetches and Realm rechecks against the same database. The replica set is local and unauthenticated, so this does not prove MongoDB TLS/authentication or multi-member failover. Loadgen capacity fixtures (thousands of robot accounts) use `credential_hash_cost = "minimum"`, so their Login Verify CPU cost is below a production Argon2 profile; single-account dev-services cases keep the default `interactive` cost.
- Results are not comparable with pre-#92 reports, whose Gateway fetch path was the `DelayedAccountFetchPort` controlled stub.
- CDN cache hit rate and the full 100k/1m production sizes require a separately approved dedicated environment; M5 remains separate.
