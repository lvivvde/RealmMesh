#!/usr/bin/env python3
"""Run remaining approved heavy verification serially after the Mac formal owner."""
import json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REMOTE='/home/edwin.guest/code/119-mongodb-ctest-20261013'
state={'mac_owner_pid':int(sys.argv[1]),'phases':[]}
def save():
 (ROOT/'pipeline-state.json').write_text(json.dumps(state,indent=2)+'\n')
def run(name,command):
 row={'name':name,'command':command,'start_wall_ns':time.time_ns(),'status':'running'}
 state['phases'].append(row);save();print('START '+name,flush=True)
 with (ROOT/(name+'.stdout')).open('w') as log:
  result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
 row.update(status='passed' if result.returncode==0 else 'failed',exit=result.returncode,end_wall_ns=time.time_ns());save()
 print('DONE '+name+' '+str(result.returncode),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
def linux(name,command):run(name,['ssh','lima-ubuntu','cd '+REMOTE+' && '+command])
save()
while subprocess.run(['ps','-p',str(state['mac_owner_pid']),'-o','stat='],capture_output=True,text=True).returncode==0:time.sleep(1)
run('mac-collect',['python3','collect-current.py',str(ROOT),str(ROOT/'mac-samples.json'),'mac'])
linux('linux-build-observers','c++ -std=c++20 -O2 tool/launcher.cpp -o launcher && cc -O2 clock-frequency.c -o clock-frequency')
for side in ('before','after','r0'):
 linux('linux-setup-'+side,'python3 paired-run.py setup '+side)
 linux('linux-refresh-'+side,'python3 paired-run.py refresh '+side)
linux('linux-formal','python3 linux-formal.py')
linux('linux-artifact-recovery','python3 additional-validation.py recovery')
linux('linux-make-fallback','python3 additional-validation.py make')
run('mac-artifact-recovery',['python3','additional-validation.py','recovery'])
run('mac-make-fallback',['python3','additional-validation.py','make'])
state['finished']=True;save()
