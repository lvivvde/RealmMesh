#!/usr/bin/env python3
"""Persist raw results and frozen reproduction inputs, with per-file hashes."""
import argparse,hashlib,json,tarfile
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('platform',choices=['mac','lima'])
parser.add_argument('root',type=Path)
parser.add_argument('out',type=Path)
args=parser.parse_args();r=args.root.resolve();out=args.out.resolve();out.mkdir(parents=True,exist_ok=True)
prefix=args.platform+'-evidence'
paths=[]
for name in ('r0-results','before-results','after-results','make-fallback-results','artifact-recovery-results','environment-clock','replay-clock','tool','diagnostic-tool','ci-repeat-fix-acceptance'):
 p=r/name
 if p.exists():paths.extend(x for x in p.rglob('*') if x.is_file() and '__pycache__' not in x.parts)
for name in ('pack-evidence.py','audit-evidence.py','audit-saved.py','restart-linux-after-sleep.py','repair-environment-capability.py','lima-samples-before-capability-repair.json.gz','invalid-clock-series.json','lima-independent-audit.json','reconstruction-verification.json','measurement-protocol.json','measurement-start.json','revisions.json','reconstruction.json','before-source-manifest.json','after-source-manifest.json','r0-source-manifest.json','paired-run.py','collect-current.py','additional-validation.py','pipeline-runner.py','pipeline-state.json','clock-monitor.py','clock-frequency.c','linux-formal.py','observer-union-check.json','mac-local-mongod-after-formal.json','mac-local-mongod-investigation.json','mac-independent-audit.json','mac-offline-audit.json','lima-offline-audit.json','supplemental-validation-summary.json','summarize-validation.py','supplement-consumer.py','mac-detached-observer-coverage.json','lima-detached-observer-coverage.json','measured-source.patch','before-detach.patch','r0-correctness.patch','mac-samples.json','lima-samples.json','ci-repeat-fix-status.json','ci-repeat-fix-full.log','linux-final-source-verification.log','dependency-restoration.json','dependency-cross-platform-verified.json'):
 p=r/name
 if p.exists():paths.append(p)
for p in r.glob('*.stdout'):paths.append(p)
paths=sorted(set(paths))
files={str(p.relative_to(r)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in paths}
manifest=out/(prefix+'.files.json');manifest.write_text(json.dumps(files,indent=2)+'\n')
archive=out/(prefix+'.tar.gz')
with tarfile.open(archive,'w:gz') as t:
 for p in paths:t.add(p,arcname=prefix+'/'+str(p.relative_to(r)))
 t.add(manifest,arcname=prefix+'/files.json')
with tarfile.open(archive,'r:gz') as t:
 for name,v in files.items():
  data=t.extractfile(prefix+'/'+name).read()
  assert len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256'],name
metadata={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files_verified':len(files)}
(out/(prefix+'.archive.json')).write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps(metadata,indent=2))
