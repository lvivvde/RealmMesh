import importlib.util,json,sys
from pathlib import Path
r=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('validation',r/'additional-validation.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
b=v.create('dev','artifact-recovery-results')
name='PlayerDataStoreTest.PersistsAccountAndSelectedCharacterAcrossReconnect'
assert name in [t['name'] for t in v.inventory(b)['tests']]
assert (b.build_dir/'tests/cpp/support/realmmesh_mongodb_fixture').is_file()
row=b.run('artifact-restored-direct-cpp-consumer',[('test',b.ctest_cmd('-R','^'+name.replace('.','\\.')+'$'))]);b.require(row,'test')
assert row['tests_total']==3 and row['tests_failed']==0
text=(b.out/row['log']).read_text();assert '***Skipped' not in text and '***Not Run' not in text
(b.out/'direct-consumer-provenance.json').write_text(json.dumps({'actual_cpp_consumer':name,'earlier_optional_regex':'QueueStoreMongoIntegrationTest.*','earlier_optional_regex_matched':False,'earlier_real_contracts_executed':2,'test_source_changed':False,'formal_samples_changed':False},indent=2)+'\n')
