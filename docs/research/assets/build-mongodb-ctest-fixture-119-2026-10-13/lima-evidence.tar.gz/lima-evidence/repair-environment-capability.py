import hashlib,json,sys
from pathlib import Path
r=Path(__file__).resolve().parent
for dirname in sys.argv[1:]:
 folder=r/dirname;p=folder/'environment.json';original=p.read_bytes();env=json.loads(original)
 assert env['quic_transport_enabled'] is None,dirname
 rows=json.loads((folder/'stages.json').read_text());evidence=[]
 for row in rows:
  if any(s['label']=='configure' for s in row['steps']):
   log=folder/row['log'];raw=log.read_bytes();lines=raw.decode(errors='replace').splitlines()
   markers=[s for s in lines if s.startswith('-- realm_network: QUIC transport')]
   assert markers and all('enabled (MsQuic found)' in s for s in markers), (dirname,row['name'],markers)
   evidence.append({'log':row['log'],'sha256':hashlib.sha256(raw).hexdigest(),'markers':markers})
 assert evidence,dirname
 (folder/'environment-capability-unresolved.json').write_bytes(original)
 env['quic_transport_enabled']=True;p.write_text(json.dumps(env,indent=2)+'\n')
 record={'reason':'frozen environment collector scans only filenames matching *configure*.log; new combined stages do not match','original_sha256':hashlib.sha256(original).hexdigest(),'derived_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'changed_fields':['quic_transport_enabled'],'actual_configure_evidence':evidence,'source_or_measurement_tools_changed':False,'new_build_or_timing_sample':False}
 (folder/'environment-capability-provenance.json').write_text(json.dumps(record,indent=2)+'\n');print(dirname,len(evidence),'real configure logs: QUIC enabled')
