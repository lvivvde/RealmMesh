import hashlib,importlib.util,json,shutil,subprocess,tarfile
from pathlib import Path
r=Path(__file__).resolve().parent
meta=json.loads((r/'invalid-clock-export/lima-evidence.archive.json').read_text())
archive=r/'invalid-clock-export'/meta['archive']
assert hashlib.sha256(archive.read_bytes()).hexdigest()==meta['sha256']
with tarfile.open(archive,'r:gz') as t:
 files=json.load(t.extractfile('lima-evidence/files.json'))
 for n,v in files.items():
  d=t.extractfile('lima-evidence/'+n).read();assert len(d)==v['bytes'] and hashlib.sha256(d).hexdigest()==v['sha256']
assert '100% tests passed, 0 tests failed out of 7' in (r/'after-sleep-failure-replay.stdout').read_text()
x=json.loads((r/'replay-clock/summary.json').read_text());assert not x['backward_steps'] and not x['wall_steps_over_50ms']
assert all('frequency_before_ppm=0.000000000 tick_before_us=10000' in v['reading'] for v in x['frequency_readings'])
old=r/'invalid-clock-working';old.mkdir()
for name in ('r0-results','before-results','after-results','environment-clock','measurement-start.json'):
 shutil.move(str(r/name),str(old/name))
clock=json.loads((old/'environment-clock/monitor/summary.json').read_text())
reason={'reason':'host sleep and VM wall clock steps: exclude entire nine-run series, not selected rows','archive_sha256':meta['sha256'],'wall_steps':len(clock['wall_steps_over_50ms']),'max_forward_shift_s':max(v['wall_vs_monotonic_shift_ns'] for v in clock['wall_steps_over_50ms'])/1e9,'source_changed':False,'clock_or_vm_settings_changed':False}
(r/'invalid-clock-series.json').write_text(json.dumps(reason,indent=2)+'\n');print(json.dumps(reason),flush=True)
spec=importlib.util.spec_from_file_location('paired',r/'paired-run.py');paired=importlib.util.module_from_spec(spec);spec.loader.exec_module(paired)
for side in ('r0','before','after'):
 b=paired.bench(side)
 row=b.run('after-sleep-transition',[('configure',b.configure_cmd()),('build',b.build_cmd())],warmup=True);b.require(row,'configure','build')
 for i in range(1,4):
  row=b.run('after-sleep-stable-'+str(i),[('configure',b.configure_cmd()),('build',b.build_cmd())],warmup=True);b.require(row,'configure','build');assert row['compile_count']==row['link_count']==0
 inventory=subprocess.check_output(['ctest','--preset','dev','--show-only=json-v1'],cwd=b.source,env=b.env,text=True)
 assert json.loads(inventory)['tests']==json.loads((old/(side+'-results/test-inventory.json')).read_text())['tests']
 (b.out/'test-inventory.json').write_text(inventory);(b.out/'environment.json').write_text(json.dumps(b.environment(['hot-full']),indent=2)+'\n')
print('ALL THREE SIDES STABLE AND INVENTORIES UNCHANGED',flush=True)
subprocess.run(['python3',str(r/'linux-formal.py')],cwd=r,check=True)
subprocess.run(['python3',str(r/'audit-evidence.py'),str(r),'lima'],cwd=r,stdout=(r/'lima-independent-audit.json').open('w'),check=True)
