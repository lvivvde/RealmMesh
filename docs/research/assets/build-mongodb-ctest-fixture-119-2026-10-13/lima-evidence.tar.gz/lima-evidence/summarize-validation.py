import json,re,sys
from pathlib import Path
r=Path(__file__).resolve().parent;platform=sys.argv[1]
def check(row,folder):
 assert row['exit']==0
 log=(folder/row['log']).read_text();assert '***Skipped' not in log and '***Not Run' not in log
 mem=row['memory'];assert mem['min_available_mib']>=1024 and mem['swap_growth_mib']==0
 assert mem['max_pressure_level']==1 if platform=='mac' else mem['oom_kills']==0
 item={k:row[k] for k in ('name','wall_s','exit','compile_count','link_count','memory')}
 item.update({k:row.get(k) for k in ('tests_total','tests_failed')});return item
out={'platform':platform,'recovery':[],'make':[]}
for kind,foldername in [('recovery','artifact-recovery-results'),('make','make-fallback-results')]:
 folder=r/foldername;rows=json.loads((folder/'stages.json').read_text());env=json.loads((folder/'environment.json').read_text())
 assert env['cache_mode']=='OFF' and env['quic_transport_enabled'] is True
 assert env['jobs']==(8 if platform=='mac' else 2)
 assert env['cmake_cache']['CMAKE_GENERATOR']==('Ninja' if kind=='recovery' else 'Unix Makefiles')
 out[kind]=[check(row,folder) for row in rows]
 if kind=='recovery':
  restore=next(x for x in rows if x['name']=='artifact-recovery');assert restore['compile_count']==0 and restore['link_count']==1
  stable=[x for x in rows if x['name'].startswith('artifact-restored-noop-')];assert len(stable)==3 and all(x['compile_count']==x['link_count']==0 for x in stable)
  assert next(x for x in rows if x['name']=='unit-aggregate')['tests_total']==504
 else:
  full=next(x for x in rows if x['name']=='make-fallback-full');assert full['tests_total']==671 and full['tests_failed']==0 and full['compile_count']==full['link_count']==0
  stable=[x for x in rows if x['name'].startswith('make-fallback-stable-')];assert len(stable)==3 and all(x['compile_count']==x['link_count']==0 for x in stable)
out['passed']=True
(r/'supplemental-validation-summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'platform':platform,'passed':True,'recovery':[(x['name'],x['tests_total']) for x in out['recovery']],'make_full_s':full['wall_s']},indent=2))
