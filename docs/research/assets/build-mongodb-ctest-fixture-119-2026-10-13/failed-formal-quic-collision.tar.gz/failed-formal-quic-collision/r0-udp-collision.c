#include <dlfcn.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
static int reservations;
static int held_udp = -1;
static int held_udp6 = -1;
static int observed_bind(int fd, const struct sockaddr *address, socklen_t length) {
    /* dyld leaves calls from the interposing image bound to the original. */
    int (*original)(int,const struct sockaddr*,socklen_t) = bind;
    int result = original(fd,address,length);
    int kind = 0; socklen_t kind_size = sizeof(kind);
    if (result == 0 && strcmp(getprogname(),"service_host_test") == 0 &&
        address->sa_family == AF_INET && ((const struct sockaddr_in*)address)->sin_port == 0 &&
        getsockopt(fd,SOL_SOCKET,SO_TYPE,&kind,&kind_size) == 0 && kind == SOCK_STREAM) {
        struct sockaddr_in actual; socklen_t size = sizeof(actual);
        getsockname(fd,(struct sockaddr*)&actual,&size);
        ++reservations;
        fprintf(stderr,"[DEBUG-r0-UDP] real TCP reservation %d: %u\n",reservations,ntohs(actual.sin_port));
        if (reservations == 3) {
            held_udp = socket(AF_INET,SOCK_DGRAM,0);
            actual.sin_addr.s_addr = htonl(INADDR_ANY);
            int occupied = original(held_udp,(struct sockaddr*)&actual,sizeof(actual));
            fprintf(stderr,"[DEBUG-r0-UDP] controlled real UDP bind port=%u result=%d\n",ntohs(actual.sin_port),occupied);
            held_udp6 = socket(AF_INET6,SOCK_DGRAM,0);
            int only6 = 1;
            setsockopt(held_udp6,IPPROTO_IPV6,IPV6_V6ONLY,&only6,sizeof(only6));
            struct sockaddr_in6 address6 = {0};
            address6.sin6_family = AF_INET6;
            address6.sin6_port = actual.sin_port;
            address6.sin6_addr = in6addr_any;
            int occupied6 = original(held_udp6,(struct sockaddr*)&address6,sizeof(address6));
            fprintf(stderr,"[DEBUG-r0-UDP] controlled real IPv6 UDP bind port=%u result=%d\n",ntohs(actual.sin_port),occupied6);
        }
    }
    return result;
}
__attribute__((used)) static const struct {const void *replacement; const void *original;} mappings[]
__attribute__((section("__DATA,__interpose"))) = {{(const void*)observed_bind,(const void*)bind}};
