#!/usr/bin/env python3
"""Public entry fallback and artifact recovery validation, after formal timings."""
import importlib.util,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('paired',ROOT/'paired-run.py')
paired=importlib.util.module_from_spec(spec);spec.loader.exec_module(paired)
measure=paired.measure

def inventory(bench):
 return json.loads(subprocess.check_output(['ctest','--preset',bench.args.preset,'--show-only=json-v1'],cwd=bench.source,env=bench.env,text=True))

def labels(inv):
 return [(t['name'],next(p['value'] for p in t['properties'] if p['name']=='LABELS')) for t in inv['tests']]

def create(preset,out):
 args=paired.bench('after').args
 args.preset=preset;args.out=str(ROOT/out)
 b=measure.Bench(args)
 b.ctest_cmd=lambda *extra:['ctest','--preset',preset,'-j','1',*extra]
 return b

if __name__=='__main__':
 measure.exit_on_sigterm()
 if sys.argv[1]=='make':
  b=create('dev-make','make-fallback-results')
  (b.build_dir/measure.SODIUM_DOWNLOAD_DIR).mkdir(parents=True,exist_ok=True)
  row=b.run('make-fallback-setup',[b.prepare_step(),('configure',b.configure_cmd()),('build',b.build_cmd())],warmup=True)
  b.require(row,'prepare','configure','build')
  for i in range(1,4):
   row=b.run('make-fallback-stable-'+str(i),[('configure',b.configure_cmd()),('build',b.build_cmd())],warmup=True)
   b.require(row,'configure','build');assert row['compile_count']==row['link_count']==0
  inv=inventory(b)
  original=json.loads((ROOT/'after-results/test-inventory.json').read_text())
  assert labels(inv)==labels(original)
  (b.out/'test-inventory.json').write_text(json.dumps(inv,indent=2)+'\n')
  row=b.run('make-fallback-full',[('configure',b.configure_cmd()),('build',b.build_cmd()),('test',b.ctest_cmd())])
  b.require(row,'configure','build','test')
  assert row['tests_failed']==0 and row['tests_total']==len(inv['tests'])
  log=(b.out/row['log']).read_text()
  assert '***Skipped' not in log and '***Not Run' not in log
  assert row['compile_count']==row['link_count']==0
  (b.out/'environment.json').write_text(json.dumps(b.environment(['make-fallback']),indent=2)+'\n')
 elif sys.argv[1]=='recovery':
  b=create('dev','artifact-recovery-results')
  helper=b.build_dir/'tests/cpp/support/realmmesh_mongodb_fixture'
  assert helper.is_file()
  helper.unlink()
  unit=subprocess.run(['ninja','-C',str(b.build_dir),'-n','realmmesh_unit_tests'],capture_output=True,text=True,env=b.env)
  (b.out/'unit-no-helper-dry-run.log').write_text(unit.stdout+unit.stderr)
  assert unit.returncode==0 and 'realmmesh_mongodb_fixture' not in unit.stdout+unit.stderr
  row=b.run('artifact-recovery',[('build',b.build_cmd())])
  b.require(row,'build')
  assert helper.is_file() and row['compile_count']==0 and row['link_count']==1
  for i in range(1,4):
   row=b.run('artifact-restored-noop-'+str(i),[('configure',b.configure_cmd()),('build',b.build_cmd())])
   b.require(row,'configure','build');assert row['compile_count']==row['link_count']==0
  row=b.run('artifact-restored-real-contracts',[('test',b.ctest_cmd('-R','^(MongoFixtureTest|MongoCtestFixtureTest|QueueStoreMongoIntegrationTest.*)$'))])
  b.require(row,'test');assert row['tests_failed']==0
  row=b.run('unit-aggregate',[('build',['cmake','--build','--preset','dev','--target','realmmesh_unit_tests','--parallel',str(b.args.jobs)]),('test',b.ctest_cmd('-L','^unit$'))])
  b.require(row,'build','test');assert row['tests_failed']==0 and row['tests_total']==504
  for row in b.rows:
   text=(b.out/row['log']).read_text()
   assert '***Skipped' not in text and '***Not Run' not in text
  (b.out/'environment.json').write_text(json.dumps(b.environment(['artifact-recovery','unit-aggregate']),indent=2)+'\n')
 else:raise SystemExit('Expected make or recovery')
