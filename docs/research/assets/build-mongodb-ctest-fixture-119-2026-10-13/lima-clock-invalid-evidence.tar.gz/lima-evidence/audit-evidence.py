#!/usr/bin/env python3
"""Independently recompute approved gates and complete-group requirements."""
import hashlib,json,statistics,sys,tarfile
from pathlib import Path
root=Path(sys.argv[1]).resolve();platform=sys.argv[2]
protocol=json.loads((root/'measurement-protocol.json').read_text())
for name,sha in protocol['tool_sha256'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
source=root/(platform+'-samples.json')
x=json.loads(source.read_text());groups=x['groups']
counts={side:len(groups[side]['samples']) for side in ('r0','before','after')}
assert len(set(counts.values()))==1,('incomplete balanced groups',counts)
n=next(iter(counts.values()));assert n in (3,5)
medians={}
for side,g in groups.items():
 env=g['environment']
 assert env['cache_mode']=='OFF' and env['quic_transport_enabled'] is True
 assert env['jobs']==(1 if side=='r0' else (8 if platform=='mac' else 2))
 assert env['cmake_cache']['CMAKE_GENERATOR']==('Unix Makefiles' if side=='r0' else 'Ninja')
 assert env['tool_sha256']['measure.py']==protocol['tool_sha256']['tool/measure.py']
 assert env['tool_sha256']['launcher.cpp']==protocol['tool_sha256']['tool/launcher.cpp']
 rows=g['samples'];assert [v['name'] for v in rows]==['hot-full-'+str(i) for i in range(1,n+1)]
 for v in rows:
  assert v['exit']==0 and v['tests_failed']==0 and v['tests_total']==len(g['inventory'])
  assert v['compile_count']==v['link_count']==v['archive_count']==v['sodium_compile_requests']==0
  assert not v['skipped_log_lines']
  mem=v['memory'];assert mem['min_available_mib']>=1024 and mem['swap_growth_mib']==0
  assert mem['max_pressure_level']==1 if platform=='mac' else mem['oom_kills']==0
 medians[side]=statistics.median(v['wall_s'] for v in rows)
 assert medians[side]==x['stats'][side]['median']
noisy=any((max(v['wall_s'] for v in g['samples'][:3])-min(v['wall_s'] for v in g['samples'][:3]))/statistics.median(v['wall_s'] for v in g['samples'][:3])>.05 for g in groups.values())
assert n==(5 if noisy else 3),('predeclared extension',n,noisy)
assert x['same_current_collection'] and all(not v for v in x['source_mismatches'].values())
gain=1-medians['after']/medians['before'];cap=1.05*medians['r0']
assert abs(gain-x['current_gain']['reduction'])<1e-12
assert cap==x['r0_cap']['limit_s']
assert medians['after']<=cap and gain>0 and x['current_gain']['faster_pairs']>n/2
assert x['resource_passed'] and x['passed']
if platform!='mac':
 assert x['clock_passed']
 for phase,record in x['clock'].items():
  assert not record['backward_steps'] and not record['wall_steps_over_50ms']
  assert all('frequency_before_ppm=0.000000000 tick_before_us=10000' in v['reading'] for v in record['frequency_readings'])
print(json.dumps({'platform':platform,'complete_groups':n,'extension_required':noisy,'median_s':medians,'gain':gain,'cap_s':cap,'headroom_s':cap-medians['after'],'passed':True},indent=2))
if len(sys.argv)>3:
 out=Path(sys.argv[3]);metadata=json.loads((out/(platform+'-evidence.archive.json')).read_text());archive=out/metadata['archive']
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==metadata['sha256'] and archive.stat().st_size==metadata['bytes']
 with tarfile.open(archive,'r:gz') as t:
  prefix=platform+'-evidence/'
  manifest=json.load(t.extractfile(prefix+'files.json'))
  assert len(manifest)==metadata['files_verified']
  for name,record in manifest.items():
   data=t.extractfile(prefix+name).read()
   assert hashlib.sha256(data).hexdigest()==record['sha256'] and len(data)==record['bytes'],name
 print('Archive SHA256 and every file verified')
