#include <chrono>
#include <cstdlib>
#include <fstream>
#include <string>
#include <sys/resource.h>
#include <sys/wait.h>
#include <unistd.h>

static std::string quote(const char* value) {
    std::string out = "\"";
    for (const unsigned char c : std::string(value)) {
        if (c == '"' || c == '\\') { out += '\\'; out += c; }
        else if (c == '\n') out += "\\n";
        else if (c == '\r') out += "\\r";
        else if (c == '\t') out += "\\t";
        else out += c;
    }
    return out + '"';
}
int main(int argc, char** argv) {
    if (argc < 2) return 2;
    using Clock = std::chrono::steady_clock;
    const auto start = Clock::now();
    const auto pid = fork();
    if (pid == 0) { execvp(argv[1], argv + 1); _exit(127); }
    if (pid < 0) return 127;
    int status = 0;
    struct rusage usage{};
    while (wait4(pid, &status, 0, &usage) < 0) {}
    const double seconds = std::chrono::duration<double>(Clock::now() - start).count();
    const int result = WIFEXITED(status) ? WEXITSTATUS(status) : 128 + WTERMSIG(status);
    if (const char* directory = std::getenv("REALMMESH_BASELINE_EVENTS")) {
        const auto stamp = start.time_since_epoch().count();
        std::ofstream file(std::string(directory) + "/" + std::to_string(getpid()) + "-" + std::to_string(stamp) + ".json");
        file.precision(12);
        file << "{\"wall_s\":" << seconds << ",\"exit\":" << result
             << ",\"maxrss_raw\":" << usage.ru_maxrss
             << ",\"user_s\":" << usage.ru_utime.tv_sec + usage.ru_utime.tv_usec / 1000000.0
             << ",\"sys_s\":" << usage.ru_stime.tv_sec + usage.ru_stime.tv_usec / 1000000.0
             << ",\"argv\":[";
        for (int i = 1; i < argc; ++i) { if (i > 1) file << ','; file << quote(argv[i]); }
        file << "]}";
    }
    return result;
}
