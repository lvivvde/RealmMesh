import argparse
import json
import os
import subprocess
import time
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--source', required=True)
p.add_argument('--out', required=True)
p.add_argument('--launcher', required=True)
p.add_argument('--name-prefix', default='')
p.add_argument('--mode', choices=['configure', 'cold', 'quick', 'noop', 'tests', 'full-only', 'http-repeat', 'script'], required=True)
p.add_argument('--cmake-arg', action='append', default=[])
a = p.parse_args()
source = Path(a.source).resolve()
out = Path(a.out).resolve()
out.mkdir(parents=True, exist_ok=True)
env = os.environ.copy()
for name in ['CMAKE_BUILD_PARALLEL_LEVEL', 'MAKEFLAGS', 'CMAKE_C_COMPILER_LAUNCHER', 'CMAKE_CXX_COMPILER_LAUNCHER']:
    env.pop(name, None)
for name in list(env):
    if 'MONGODB' in name and ('URI' in name or 'PASSWORD' in name):
        env.pop(name, None)
env['LC_ALL'] = 'C'
rows = json.loads((out / 'stages.json').read_text()) if (out / 'stages.json').exists() else []

def run(name, command):
    name = a.name_prefix + name
    events = out / (name + '-events')
    events.mkdir(exist_ok=True)
    stage_env = env.copy()
    stage_env['REALMMESH_BASELINE_EVENTS'] = str(events)
    log = out / (name + '.log')
    timeline = out / (name + '.timeline.jsonl')
    start = time.perf_counter()
    print('START ' + name, flush=True)
    with log.open('w', buffering=1) as stream, timeline.open('w', buffering=1) as ts:
        proc = subprocess.Popen(command, cwd=source, env=stage_env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors='replace')
        for line in proc.stdout:
            stream.write(line)
            if any(x in line for x in ['Building ', 'Linking ', 'Performing ', 'Downloading', 'Test #', 'Test  #', 'tests passed', 'QUIC transport']):
                ts.write(json.dumps({'elapsed_s':time.perf_counter()-start, 'line':line.rstrip()}) + '\n')
        result = proc.wait()
    elapsed = time.perf_counter() - start
    compiled = []
    linked = []
    for f in events.glob('*.json'):
        event = json.loads(f.read_text())
        argv = event['argv']
        event['kind'] = 'compile' if '-c' in argv else 'link'
        event['source'] = next((x for x in argv if x.endswith(('.c','.cc','.cpp','.cxx'))), None)
        event['dependency'] = bool(event['source'] and ('/_deps/' in event['source']))
        (compiled if event['kind'] == 'compile' else linked).append(event)
    row = {'name':name, 'command':command, 'wall_s':elapsed, 'exit':result, 'compile_count':len(compiled), 'link_count':len(linked),
           'compile_wall_sum_s':sum(e['wall_s'] for e in compiled), 'dependency_compile_wall_sum_s':sum(e['wall_s'] for e in compiled if e['dependency']),
           'project_compile_wall_sum_s':sum(e['wall_s'] for e in compiled if not e['dependency']), 'link_wall_sum_s':sum(e['wall_s'] for e in linked),
           'log':log.name, 'events':events.name, 'compiled_sources':[e['source'] for e in compiled]}
    rows.append(row)
    (out/'stages.json').write_text(json.dumps(rows,indent=2))
    print('DONE ' + json.dumps({k:row[k] for k in ['name','wall_s','exit','compile_count','link_count']}),flush=True)
    return result

configure = ['cmake','--preset','dev'] + [f'-DCMAKE_{lang}_{kind}_LAUNCHER={a.launcher}' for lang in ['C','CXX'] for kind in ['COMPILER','LINKER']] + a.cmake_arg
build = ['cmake','--build','--preset','dev']
if a.mode == 'configure':
    raise SystemExit(run('configure-first', configure))
if a.mode == 'cold':
    raise SystemExit(run('build-cold', build))
if a.mode == 'quick':
    for i in range(3): run(f'configure-warm-{i+1}', configure)
    for i in range(3): run(f'build-noop-{i+1}', build)
    for label, relative in [('cpp','framework/scripting/src/lua_runtime.cpp'), ('header','framework/scripting/include/realmmesh/scripting/lua_runtime.hpp')]:
        f = source/relative
        original = f.read_bytes()
        try:
            for i in range(3):
                f.write_bytes(original + f'\n// baseline {label} content-change sample {i+1}\n'.encode())
                if run(f'build-{label}-{i+1}', build): break
        finally:
            f.write_bytes(original)
        run(f'build-{label}-restore', build)
if a.mode == 'noop':
    for i in range(3): run(f'build-stable-noop-{i+1}', build)
if a.mode == 'http-repeat':
    for i in range(3): run(f'test-http-halfclose-{i+1}', ['ctest','--preset','dev','-R','^HttpServerTest.DeferredResponseSurvivesClientHalfClose$'])
if a.mode == 'full-only':
    run('test-full', ['ctest','--preset','dev'])
if a.mode == 'tests':
    inventory = subprocess.check_output(['ctest','--preset','dev','--show-only=json-v1'],cwd=source,env=env,text=True)
    (out/'ctest-inventory.json').write_text(inventory)
    for i in range(3): run(f'test-unit-{i+1}', ['ctest','--preset','dev','-L','unit'])
    run('test-full', ['ctest','--preset','dev'])
if a.mode == 'script':
    run('script-full', ['bash','scripts/build.sh'])
