# Ninja、编译 launcher 与 libsodium 的兼容性事实
日期：2026-10-02。代码 HEAD 14c19d08d42ea4653914c91a82d6b971541c6cb6；只读仓库。工具为 CMake 4.4.3、GNU Make 3.81、Apple clang 21.0.0。PATH 无 Ninja、ccache、sccache；未安装这些工具，未执行 RealmMesh 全量构建。小探针只验证机制，不产生提速结论。

## 当前源码事实
third_party/sodium/CMakeLists.txt 12–19：Autotools configure 后裸 $(MAKE) / $(MAKE) install；没有显式 CC、编译 launcher 或子构建 jobs。21 行 BUILD_BYPRODUCTS 声明安装目录的静态库，24–30 行 imported target 并依赖 sodium_external。
proto/CMakeLists.txt 18–32：输出生成源码及头全部列在 OUTPUT；COMMAND 使用 protobuf::protoc，DEPENDS 包含工具目标和当前三份 proto；VERBATIM 已启用。
CMakePresets.json：当前 dev=Unix Makefiles，仅有该预设。

## 工具机制与最低版本
1. 外部 Autotools make 不能使用 Ninja 配置的 CMAKE_MAKE_PROGRAM；后者是 ninja。需要保留 Make 生成器的递归 make 形式，或独立 find_program(gmake/make REQUIRED) 并在 configure 阶段缺失时报错。[CMake 3.20 ExternalProject 示例](https://cmake.org/cmake/help/v3.20/module/ExternalProject.html)
2. CMake 为非 CMake ExternalProject 选择默认命令时明确区分 Makefiles 的 $(MAKE) 与其他生成器的 make；当前 wrapper 显式 BUILD_COMMAND 覆盖了这个默认行为。本机 ExternalProject.cmake 1785–1803行直接验证。未执行 Ninja，不能据此声称整个工程已兼容。
3. 原生 C/C++ target 在创建时继承 CMAKE_C/CXX_COMPILER_LAUNCHER；Make 与 Ninja 支持。C/CXX 的能力从3.4存在；3.25 generator expressions不是3.20必要方案。[官方属性说明](https://cmake.org/cmake/help/v3.26/prop_tgt/LANG_COMPILER_LAUNCHER.html)
4. 明确指定的 Autotools configure 不会自动把原生 CMake compiler/flags/launcher 接进去。可用3.20已有 cmake -E env 和独立 compiler wrapper显式接线，但需分别验证真实 CC/CCAS、SDK/架构、必要编译参数、launcher实际调用和空缓存/命中统计；不能直接把所有CMake CFLAGS照搬过去。
5. 顶层 Ninja jobs 与外部 make jobs不是自动统一预算；并行数必须限制嵌套过量。Ninja1.13 GNU jobserver能力是“由已有make jobserver驱动Ninja”，不是“Ninja自动给它启动的make子项目发同一jobserver”；POSIX仅支持Make4.4+ FIFO，Apple Make3.81不满足。[Ninja官方手册](https://ninja-build.org/manual.html)
6. INSTALL_BYPRODUCTS需3.26，BUILD_JOB_SERVER_AWARE需3.28，INSTALL_JOB_SERVER_AWARE需4.0，不能作为保留3.20下限的必选接线。[官方版本注记](https://cmake.org/cmake/help/latest/module/ExternalProject.html)
7. BUILD_BYPRODUCTS支持3.20；Ninja要求依赖的生成文件有producer。[CMake 3.20 custom command](https://cmake.org/cmake/help/v3.20/command/add_custom_command.html) 当前静态库标注在build步，但实际位于install目录。首批必须检查真正的生产步骤和删除后的恢复；不因已有一个byproducts条目就声称所有产物可恢复。

## 小型探针
本目录 recursive.json、explicit.json 保存完整命令和输出；各项目只有一个原生小C对象、一个外部Make小C对象，无网络、无安装动作。每个原生编译通过launcher（launcher.log共两次），外部编译没有通过launcher。证明CMake launcher不覆盖任意外部Make编译，不能据此推断ccache收益。
两种Make命令都输出MAKEFLAGS jobserver字段；仅观察环境字符串，未测量实际并发/FD可用性，不能宣称explicit make通用共享jobserver。
探针运行CMake4.4.3，不是3.20实际执行；最低能力只按官方版本说明核对。

## 首批验收与退出门槛
- 生成器使用独立构建目录；不能在原Make缓存上直接切Ninja。
- 冷构建、原生最小target和Lua/unit汇总、全量构建/CTest必须在双平台通过，并记录QUIC开启条件；源码/公共头增量和稳定无操作复测。
- 同jobs比较Make/Ninja；空编译缓存、命中重建、稳定无操作分别报告，不能把并行收益计入生成器收益。
- libsodium静态库及安装头先后依赖在高并行下无竞态；删除单个生成库/头后能够明确恢复或给精确修复操作，不能依靠整个build删除。
- proto修改或删除生成头/源码能重生；工具替换路径/版本后重新生成；以后新增import需纳入依赖，不凭现有三份列表保证未来覆盖。
- 验证编译数据库、clang tooling以及索引读取；launcher只在确认存在时开启，明确的cache-off路径可执行。
- 任一生成/产物恢复/行为门槛失败，则Ninja不成为默认；保留独立Make入口用于归因。当前未实施这项策略，以上是候选验收，不替用户决定。

图证据：TierVerify project Users-edwin-Projects-RealmMesh，generation2026-10-02T12:27:02Z、recorded12:30:32Z完整。sodium为third_party excluded已全文读取，proto/preset metadata_match无记录缺口；不做全库结构完整性结论。
