int external_value(void){return 2;}
