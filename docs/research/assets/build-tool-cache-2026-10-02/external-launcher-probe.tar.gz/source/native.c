int native_value(void){return 1;}
