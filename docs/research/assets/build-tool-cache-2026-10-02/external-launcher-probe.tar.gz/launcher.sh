#!/bin/sh
printf "%s\n" "$*" >> "/private/tmp/realmmesh-external-compat-4c13mqcr/launcher.log"
exec "$@"
