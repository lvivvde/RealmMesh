set_property(GLOBAL PROPERTY RULE_LAUNCH_COMPILE "\"/home/edwin.guest/code/.bench/p6-clock-fixed-20261007/launcher\"")
