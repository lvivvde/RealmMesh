#!/usr/bin/env python3
import json,time
from pathlib import Path
root=Path(__file__).resolve().parent
for _ in range(80):
 files=[p for s in ('r0','before','after') for p in (root/(s+'-results')).glob('hot-full-*.log')]
 if files:
  p=max(files,key=lambda p:p.stat().st_mtime_ns)
  lines=p.read_text().splitlines()
  latest=next((l.strip() for l in reversed(lines) if 'Test #' in l or 'Test  #' in l),'')
  stages=json.loads((p.parent/'stages.json').read_text()) if (p.parent/'stages.json').exists() else []
  done=[{'name':r['name'],'wall_s':r['wall_s'],'exit':r['exit']} for r in stages if r['name'].startswith('hot-full-')]
  print(json.dumps({'file':str(p.relative_to(root)),'latest':latest,'completed_in_side':done}),flush=True)
 if (root/'lima-samples.json').exists():
  print('COLLECTION COMPLETE',flush=True);break
 if 'Traceback' in (root/'linux-rerun.stdout').read_text():
  print('CONTROLLER FAILED: '+(root/'linux-rerun.stdout').read_text()[-1200:],flush=True);break
 time.sleep(45)
