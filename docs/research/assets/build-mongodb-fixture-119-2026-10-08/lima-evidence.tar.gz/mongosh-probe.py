#!/usr/bin/python3
import json,os,subprocess,sys,time
script=sys.argv[sys.argv.index('--eval')+1] if '--eval' in sys.argv else ''
kind=('initiate' if 'rs.initiate(' in script else 'primary' if 'db.hello().isWritablePrimary' in script else 'ping' if 'ping:' in script else 'eval')
started=time.monotonic_ns()
status=subprocess.call([os.environ['REALMMESH_PROBE_REAL_MONGOSH'],*sys.argv[1:]])
row=dict(kind=kind,pid=os.getpid(),parent=os.getppid(),start_ns=started,wall_s=(time.monotonic_ns()-started)/1e9,exit=status)
fd=os.open(os.environ['REALMMESH_PROBE_MONGOSH_LOG'],os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
os.write(fd,(json.dumps(row)+'\n').encode());os.close(fd)
sys.exit(status)
