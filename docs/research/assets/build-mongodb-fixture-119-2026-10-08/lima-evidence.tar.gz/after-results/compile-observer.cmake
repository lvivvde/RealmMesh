set_property(GLOBAL PROPERTY RULE_LAUNCH_COMPILE "\"/home/edwin.guest/code/119-mongodb-cost-20261008/launcher\"")
