import json,os,subprocess,time
from pathlib import Path
r=Path('/home/edwin.guest/code/119-mongodb-cost-20261008')
src=Path('/home/edwin.guest/code/.bench/issue119-fixture-20261007/source')
env=os.environ.copy()
for k in list(env):
 if k.startswith('CCACHE_') or k in ('MAKEFLAGS','CMAKE_BUILD_PARALLEL_LEVEL','CTEST_PARALLEL_LEVEL') or ('MONGODB' in k and ('URI' in k or 'PASSWORD' in k)):env.pop(k)
env.update(TMPDIR=str(r/'tmp-disk'),REALMMESH_MONGOD_BINARY='/home/edwin.guest/code/RealmMesh/.tools/mongodb-8.0.32/bin/mongod',REALMMESH_MONGOSH_BINARY=str(r/'mongosh-probe.py'),REALMMESH_PROBE_REAL_MONGOSH='/home/edwin.guest/code/RealmMesh/.tools/mongosh-2.12.0/bin/mongosh',REALMMESH_PROBE_MONGOSH_LOG=str(r/'linux-mongosh-events.jsonl'))
cmd=['ctest','--test-dir',str(src/'build/dev-ninja'),'-j','1','--output-on-failure']
t=time.monotonic_ns()
with (r/'linux-profile-full.log').open('w') as f:status=subprocess.call(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
(r/'linux-profile-full.json').write_text(json.dumps(dict(command=cmd,exit=status,wall_s=(time.monotonic_ns()-t)/1e9,instrumented=True),indent=2)+'\n')
print('Linux diagnostic finished',status,flush=True)
raise SystemExit(status)
