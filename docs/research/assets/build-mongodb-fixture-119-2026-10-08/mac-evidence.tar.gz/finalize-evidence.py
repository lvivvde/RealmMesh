from pathlib import Path
import json,hashlib,subprocess,tarfile,shutil
r=Path('/private/tmp/realmmesh-119-mongodb-next')
compact={}
keys=['platform','revisions','collection_counts','same_current_collection','r0_collection_difference','stats','current_gain','r0_cap','resources','resource_passed','passed','clock','clock_passed']
for platform in ['mac','lima']:
 x=json.loads((r/f'{platform}-samples.json').read_text())
 compact[platform]={k:x[k] for k in keys if k in x}
 compact[platform]['capability_audit']=json.loads((r/f'{platform}-capability-audit.json').read_text())
compact['code_ci']=json.loads((r/'pr149-ci-audit.json').read_text())
compact['excluded_lima_epoch']=json.loads((r/'lima-invalid-clock-summary.json').read_text())
(r/'summary.json').write_text(json.dumps(compact,ensure_ascii=False,indent=2)+'\n')
review=json.loads((r/'review-result.json').read_text());review['evidence_draft_review']['lima_results_pending']=False
(r/'review-result.json').write_text(json.dumps(review,indent=2)+'\n')
s=(r/'report-draft.md').read_text()
s=s.replace('本轮原生初始化在 Mac 上通过同当前合集收益门槛（3/3 配对更快，中位缩短 7.05%），\n但未通过同期 R0 的 5% 上限：375.178 秒高于 365.969 秒上限，还差 9.209 秒。\nLima 正式采样完成后单列结果。#119 必须继续保持打开；本轮结果不等于整体目标达标。','本轮原生初始化在 Mac 和 Lima 均通过同当前合集收益门槛（各 3/3 配对更快，\n中位分别缩短 7.05% 和 4.58%），但均未通过同期 R0 的 5% 上限：Mac 还差\n9.209 秒，Lima 还差 0.902 秒。#119 继续保持打开；本轮结果不等于整体目标达标。')
t=['完整连续入口墙钟（秒），三组使用预定顺序；中位数由完整入口直接计算：','', '| 平台 / 来源 | 第 1 组 | 第 2 组 | 第 3 组 | 中位数 | 最小—最大 |','|---|---:|---:|---:|---:|---:|']
for p in ['mac','lima']:
 for name in ['r0','before','after']:
  a=compact[p]['stats'][name];v=a['values'];t.append(f"| {p} / {name} | {v[0]:.3f} | {v[1]:.3f} | {v[2]:.3f} | {a['median']:.3f} | {a['min']:.3f}—{a['max']:.3f} |")
t+=['','| 平台 | 当前同合集降幅 | 配对更快 | R0 × 1.05 上限 | 优化后 / R0 | 尚需缩短 | 5% 上限 |','|---|---:|---:|---:|---:|---:|---|']
for p in ['mac','lima']:
 a=compact[p];g=a['current_gain'];c=a['r0_cap'];t.append(f"| {p} | {g['reduction']*100:.2f}% | {g['faster_pairs']}/3 | {c['limit_s']:.3f} 秒 | {c['ratio']:.6f} | {-c['headroom_s']:.3f} 秒 | 未通过 |")
s=s.replace('[统计]','\n'.join(t))
s=s.replace('OOM 计数，记为 null，不将它写成已观察到零次。Lima 资源和时钟结果待汇总。','OOM 计数，记为 null，不将它写成已观察到零次。Lima 九次正式入口最大进程树\nRSS 693.188 MiB，最低可用内存 2225.879 MiB，最大 swap 增量 0，全部有效\n样本的内核 OOM 计数均可观测且为 0。45.022 秒时钟预检及 2886.041 秒连续\n观察均无倒退或超过门槛的跳变；连续观察覆盖失败重放、稳定检查及九次替代正式入口。')
s=s.replace('Mac 九次完整入口（R0 各 649、当前两侧各 668）全部通过，无失败或跳过；','两平台各九次有效完整入口（R0 各 649、当前两侧各 668）全部通过，无失败或跳过；')
s=s.replace('仅构建其消费者即可恢复；守卫通过，随后构建无编译/链接。','仅构建其消费者即可恢复；守卫通过，随后构建无编译/链接。两平台均完成这些检查；\n回退与恢复检查的墙钟不进入正式性能统计。')
s=s.replace('沿用完全相同来源、工具、资源与顺序，先重放失败用例，再做完整三组替代采样。','沿用完全相同来源、工具、资源与顺序，先重放失败用例（2/2 通过，104.90 秒），\n再做完整三组替代采样。采样期间使用本轮拥有的防睡眠断言；验证结束只释放该进程。')
(r/'report-final.md').write_text(s)
print('summary/report finalized')
