#include <mongoc/mongoc.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

/* Diagnostic only: run the two existing fixture commands against real mongod. */
int main(int argc, char **argv) {
    if (argc < 6) return 64;
    const char *script = argv[argc - 1];
    if (!strstr(script, "rs.initiate(") && strcmp(script, "print(db.hello().isWritablePrimary)") &&
        strcmp(script, "db.adminCommand({ping: 1}).ok")) {
        const char *fallback = getenv("REALMMESH_PROBE_MONGOSH_FALLBACK");
        if (!fallback) return 64;
        execv(fallback, argv);
        return 127;
    }
    mongoc_init();
    const char *connection = NULL;
    for (int i = 1; i < argc; ++i) if (strncmp(argv[i], "mongodb://", 10) == 0) connection = argv[i];
    if (!connection) { mongoc_cleanup(); return 64; }
    mongoc_uri_t *uri = mongoc_uri_new(connection);
    if (!uri) return 64;
    mongoc_uri_set_option_as_int32(uri, MONGOC_URI_SERVERSELECTIONTIMEOUTMS, 1000);
    mongoc_uri_set_option_as_int32(uri, MONGOC_URI_CONNECTTIMEOUTMS, 1000);
    mongoc_uri_set_option_as_int32(uri, MONGOC_URI_SOCKETTIMEOUTMS, 1000);
    mongoc_client_t *client = mongoc_client_new_from_uri(uri);
    bson_t command = BSON_INITIALIZER;
    bson_t reply;
    bson_error_t error;
    int code = 0;
    if (strstr(script, "rs.initiate(")) {
        bson_t config, members, member;
        BSON_APPEND_DOCUMENT_BEGIN(&command, "replSetInitiate", &config);
        BSON_APPEND_UTF8(&config, "_id", "rs0");
        BSON_APPEND_ARRAY_BEGIN(&config, "members", &members);
        BSON_APPEND_DOCUMENT_BEGIN(&members, "0", &member);
        BSON_APPEND_INT32(&member, "_id", 0);
        BSON_APPEND_UTF8(&member, "host", mongoc_uri_get_hosts(uri)->host_and_port);
        bson_append_document_end(&members, &member);
        bson_append_array_end(&config, &members);
        bson_append_document_end(&command, &config);
        if (!mongoc_client_command_simple(client, "admin", &command, NULL, &reply, &error) && error.code != 23) {
            fprintf(stderr, "%s\n", error.message); code = 1;
        } else {
            struct timespec started, now;
            clock_gettime(CLOCK_MONOTONIC, &started);
            bool primary = false;
            do {
                bson_t hello = BSON_INITIALIZER, result;
                BSON_APPEND_INT32(&hello, "hello", 1);
                if (mongoc_client_command_simple(client, "admin", &hello, NULL, &result, &error)) {
                    bson_iter_t it;
                    primary = bson_iter_init_find(&it, &result, "isWritablePrimary") && BSON_ITER_HOLDS_BOOL(&it) && bson_iter_bool(&it);
                }
                bson_destroy(&result);bson_destroy(&hello);
                if (primary) break;
                usleep(20000);
                clock_gettime(CLOCK_MONOTONIC, &now);
            } while (now.tv_sec - started.tv_sec < 30);
            if (primary) puts("ok"); else {fprintf(stderr,"primary deadline exceeded\n");code=1;}
        }
    } else if (strcmp(script, "print(db.hello().isWritablePrimary)") == 0) {
        BSON_APPEND_INT32(&command, "hello", 1);
        if (!mongoc_client_command_simple(client, "admin", &command, NULL, &reply, &error)) {
            fprintf(stderr, "%s\n", error.message); code = 1;
        } else {
            bson_iter_t it;
            puts(bson_iter_init_find(&it, &reply, "isWritablePrimary") &&
                 BSON_ITER_HOLDS_BOOL(&it) && bson_iter_bool(&it) ? "true" : "false");
        }
    } else {
        BSON_APPEND_INT32(&command, "ping", 1);
        if (!mongoc_client_command_simple(client, "admin", &command, NULL, &reply, &error)) {
            fprintf(stderr, "%s\n", error.message);code=1;
        } else puts("1");
    }
    bson_destroy(&reply);
    bson_destroy(&command);
    mongoc_client_destroy(client);
    mongoc_uri_destroy(uri);
    mongoc_cleanup();
    return code;
}
