set_property(GLOBAL PROPERTY RULE_LAUNCH_COMPILE "\"/private/tmp/realmmesh-p6-fixed/launcher\"")
