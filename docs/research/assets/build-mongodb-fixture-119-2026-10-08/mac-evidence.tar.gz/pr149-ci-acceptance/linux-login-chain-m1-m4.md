# Linux Login Chain M1–M4 acceptance

- Started: 2026-10-08T15:17:33Z
- Platform: Ubuntu 24.04.5 LTS; kernel 6.17.0-1022-azure; x86_64
- CPU: 4 logical; INTEL(R) XEON(R) PLATINUM 8573C
- Memory: 16372440 KiB
- File-descriptor limit: 65536
- Revision: `820b1ffd343797486c64496b13e3b402ec206b6e` (clean working tree)
- Build: preset `dev`; directory `/home/runner/work/RealmMesh/RealmMesh/build/dev-ninja`
- Topology: one Linux host; production service/loadgen paths in the dev-preset build; four independent service processes where required; temporary real etcd
- Transport: real MsQuic server/client exchange plus production Login Chain TLS/TCP fallback
- Repetitions: transport/M1/M2=3; M3/M4=1
- Raw log: `linux-login-chain-m1-m4.log`

## Command

`REALMMESH_ACCEPTANCE_REPEATS=3 REALMMESH_LINUX_ACCEPTANCE_SKIP_BUILD=1 ./scripts/run-linux-login-acceptance.sh --preset dev`

## Acceptance levels

| Level | CI-scale input and gate | Production target from #32 |
|---|---|---|
| Transport | real QUIC verified stream; TLS/TCP staged fallback; certificate failure must not fall back | both Gateway and Realm candidate paths |
| M1 | 100 Gateway sessions for 5s; concurrent multi-stage water; attach P99 <=5x same-load baseline; no fd growth | 100k mixed sessions for 30 min; <=3 GB; no P99 drift/fd/OOM |
| M2 | 250 robots/64 concurrency/25s; >=248 complete; fetch failures <1% | 100k robots handed off in 60s |
| M3 | 10k durable tickets + 2k progress clients; >=99.9% success | 1m tickets; origin <=5k QPS; cache hit >=99% |
| M4 | Gateway/Realm budget-key convergence <=10s; Queue cold recovery <=30s; released number monotonic; no Grant replay | same gates on staged topology |

> The CI profile is a deterministic regression baseline. It reports, but does not claim, the dedicated-host 100k/1m capacity targets. M5 remains out of scope.

## Source configuration

```text
badf4cc0e32b5da4a7c84da777978704f2a37ff71b021332ae2f16b3e94bcfbb  configs/main.config
c2a7f81fc5fbe8598978ad82f0b7fef37f3325d21813bdb889c06a2f0e3d6eb7  configs/common/discovery.lua
f34f4b853456c2fbab99c51a12cd2e9428bb31cfb76b93d8ad9d370026101068  configs/common/player_data.lua
9219d59f3fc2b25daab02b01a575dcd942e79f2c39821931384b29177a91d8b4  configs/services/login_verify.lua
8b1bf0b7741e3b2edf320c601662a9419ad8a1079a0f2963e0605f783044e559  configs/services/queue.lua
4be72b8bbec6b7c58dcff27cac3f673b5f9366ad85f5ce806b4a5008d8cbd371  configs/services/gateway.lua
d2096415e096a6fa731d4b533473af9f8071fac66c98304e9f77b96e84c773ac  configs/services/realm.lua
f5d7d56f439a65029b9b2b9a54f3a6a85723feaadda9c8b1810e49205b3f7ba0  .github/workflows/ci.yml
```

## Results

| Group | Runs | Elapsed | Result |
|---|---:|---:|---|
| Transport and topology | 3 | 13s | PASS |
| M1 directed soak | 3 | 69s | PASS |
| M2 admission and durable issuance | 3 | 37s | PASS |
| M3 ticket and progress load | 1 | 59s | PASS |
| M4 failure and recovery | 1 | 63s | PASS |

## Measured evidence

```text
16: acceptance_runtime login_verify=127.0.0.1:27230 queue=127.0.0.1:29573 gateway=127.0.0.1:29636 realm=127.0.0.1:25568 etcd=http://127.0.0.1:28002 mongodb=127.0.0.1:23111
16: acceptance_runtime_config badf4cc0e32b5da4a7c84da777978704f2a37ff71b021332ae2f16b3e94bcfbb  configs/main.config
16: acceptance_runtime_config ff9f5884cf0435f666eca3362da24cb4fe02c604f331bfeb7b0d4118ba27c002  configs/common/discovery.lua
16: acceptance_runtime_config 69b5c275f09cbca512ae487c308a2b07accc71404e48b11c3dd5973212203b63  configs/common/accounts.lua
16: acceptance_runtime_config 022451fbfa6d3779f5fea351ab41ee6789dc30a96a87c95b43a3de73869642a8  configs/common/player_data.lua
16: acceptance_runtime_config f0390579a757e9855b3ef9af69447ff6f0b0d5b4112ce671d4fb39cd255b8d49  configs/services/login_verify.lua
16: acceptance_runtime_config 318420732174d8df07f5e38bd50be1d440df18fc6d83d0560e36d0e24da3cc9b  configs/services/queue.lua
16: acceptance_runtime_config ec21d8cadca8476ead26f6e92759941ce084bc3bddc8540f3f2c3583fda16962  configs/services/gateway.lua
16: acceptance_runtime_config b7fc5cceb99d918a7016c85ea437ac18c9c2cd6918ed39296170f26d20d97237  configs/services/realm.lua
16: loadgen report
16: robots: 1  completed: 1
16: verify: attempts=1 failures=0 p50_ms=183.617079 p99_ms=183.617079 max_ms=183.617079
16: tickets: attempts=1 failures=0 p50_ms=155.987872 p99_ms=155.987872 max_ms=155.987872
16: poll: attempts=28 failures=0 p50_ms=0.177268 p99_ms=50.225664 max_ms=50.225664
16: attach: attempts=1 failures=0 p50_ms=42.057098 p99_ms=42.057098 max_ms=42.057098
16: handoff: attempts=1 failures=0 p50_ms=90.676444 p99_ms=90.676444 max_ms=90.676444
16: realm: attempts=1 failures=0 p50_ms=42.188975 p99_ms=42.188975 max_ms=42.188975
16: acceptance_runtime login_verify=127.0.0.1:26133 queue=127.0.0.1:29508 gateway=127.0.0.1:26319 realm=127.0.0.1:27608 etcd=http://127.0.0.1:20575 mongodb=127.0.0.1:23672
16: acceptance_runtime_config badf4cc0e32b5da4a7c84da777978704f2a37ff71b021332ae2f16b3e94bcfbb  configs/main.config
16: acceptance_runtime_config dc051865958b9b16adcf3a8c31b9604bd59a3bb553e28660533e9664bc087831  configs/common/discovery.lua
16: acceptance_runtime_config 69b5c275f09cbca512ae487c308a2b07accc71404e48b11c3dd5973212203b63  configs/common/accounts.lua
16: acceptance_runtime_config 1358a03250270be980e6bf427a5b451f6c0617d25273198ef461e1b0c4ef2c9c  configs/common/player_data.lua
16: acceptance_runtime_config 14360ff89c235a4bfc310b9365c921f01c4c685c5adf483851e0901584115598  configs/services/login_verify.lua
16: acceptance_runtime_config 9335a59680e372d7a21ddb0e1337bfcda75bafc704d15bd61addef73f703de85  configs/services/queue.lua
16: acceptance_runtime_config 9d91837e514bcb5756edf20e9581c4b385c73db3d258900626a9308323bfe013  configs/services/gateway.lua
16: acceptance_runtime_config 8a7576ff219d4ae13e057967a65817a07b5e93105ed20eda28d95fe9a5a7f0ad  configs/services/realm.lua
16: loadgen report
16: robots: 1  completed: 1
16: verify: attempts=1 failures=0 p50_ms=181.210740 p99_ms=181.210740 max_ms=181.210740
16: tickets: attempts=1 failures=0 p50_ms=159.388040 p99_ms=159.388040 max_ms=159.388040
16: poll: attempts=28 failures=0 p50_ms=0.225150 p99_ms=49.198007 max_ms=49.198007
16: attach: attempts=1 failures=0 p50_ms=41.122493 p99_ms=41.122493 max_ms=41.122493
16: handoff: attempts=1 failures=0 p50_ms=95.705306 p99_ms=95.705306 max_ms=95.705306
16: realm: attempts=1 failures=0 p50_ms=42.900496 p99_ms=42.900496 max_ms=42.900496
16: acceptance_runtime login_verify=127.0.0.1:27759 queue=127.0.0.1:29820 gateway=127.0.0.1:23879 realm=127.0.0.1:28025 etcd=http://127.0.0.1:20484 mongodb=127.0.0.1:25239
16: acceptance_runtime_config badf4cc0e32b5da4a7c84da777978704f2a37ff71b021332ae2f16b3e94bcfbb  configs/main.config
16: acceptance_runtime_config 34364bb45944c49980b49725201c8a21de7491086eb60e95994f1eb133dde579  configs/common/discovery.lua
16: acceptance_runtime_config 69b5c275f09cbca512ae487c308a2b07accc71404e48b11c3dd5973212203b63  configs/common/accounts.lua
16: acceptance_runtime_config 3c877159bf2fd3e4aea80f5343f041ddcaba04037686a97d87d191b226da3ec7  configs/common/player_data.lua
16: acceptance_runtime_config 6f7def07748ac8fe8b3479838704d1e7c02b2b6e3c1e62c90c43447136dac943  configs/services/login_verify.lua
16: acceptance_runtime_config 4227a4aed67d5cde1846afe6de91c6fdf03f9381890ee50b9db716dab9c98bcd  configs/services/queue.lua
16: acceptance_runtime_config edd18ac4cf8b85e19886f521c5831cd4f95d6bee280b610e8da9c7a302cd6702  configs/services/gateway.lua
16: acceptance_runtime_config 5797b6fa9fb405d69050067e3dcae1e12554022bc996659cf035c84af8f976ba  configs/services/realm.lua
16: loadgen report
16: robots: 1  completed: 1
16: verify: attempts=1 failures=0 p50_ms=186.057061 p99_ms=186.057061 max_ms=186.057061
16: tickets: attempts=1 failures=0 p50_ms=159.163604 p99_ms=159.163604 max_ms=159.163604
16: poll: attempts=28 failures=0 p50_ms=0.223645 p99_ms=49.489126 max_ms=49.489126
16: attach: attempts=1 failures=0 p50_ms=41.287804 p99_ms=41.287804 max_ms=41.287804
16: handoff: attempts=1 failures=0 p50_ms=85.173654 p99_ms=85.173654 max_ms=85.173654
16: realm: attempts=1 failures=0 p50_ms=47.719074 p99_ms=47.719074 max_ms=47.719074
659: acceptance_m1 gateway_soak completed=100 attach_failures=0 handoff_failures=0 capacity=20000 max_pending=0 max_fetching=54 max_handed_off=100 mixed_water_sample=1 water_samples=663 baseline_attach_p50_ms=275.499 main_attach_p50_ms=192.174 baseline_attach_p99_ms=333.785 main_attach_p99_ms=266.263 fd_before=48 fd_after=48
659: acceptance_m1 gateway_soak completed=100 attach_failures=0 handoff_failures=0 capacity=20000 max_pending=0 max_fetching=55 max_handed_off=100 mixed_water_sample=1 water_samples=722 baseline_attach_p50_ms=249.853 main_attach_p50_ms=180.075 baseline_attach_p99_ms=327.655 main_attach_p99_ms=260.931 fd_before=48 fd_after=48
659: acceptance_m1 gateway_soak completed=100 attach_failures=0 handoff_failures=0 capacity=20000 max_pending=0 max_fetching=64 max_handed_off=100 mixed_water_sample=1 water_samples=744 baseline_attach_p50_ms=255.1 main_attach_p50_ms=244.711 baseline_attach_p99_ms=324.139 main_attach_p99_ms=299.541 fd_before=48 fd_after=48
661: loadgen report
661: robots: 1  completed: 1
661: verify: attempts=1 failures=0 p50_ms=50.865222 p99_ms=50.865222 max_ms=50.865222
661: tickets: attempts=1 failures=0 p50_ms=53.011133 p99_ms=53.011133 max_ms=53.011133
661: poll: attempts=37 failures=0 p50_ms=4.024925 p99_ms=4.489117 max_ms=4.489117
661: attach: attempts=1 failures=0 p50_ms=41.480506 p99_ms=41.480506 max_ms=41.480506
661: handoff: attempts=1 failures=0 p50_ms=0.043647 p99_ms=0.043647 max_ms=0.043647
661: realm: attempts=1 failures=0 p50_ms=42.905484 p99_ms=42.905484 max_ms=42.905484
661: loadgen report
661: robots: 1  completed: 1
661: verify: attempts=1 failures=0 p50_ms=50.935430 p99_ms=50.935430 max_ms=50.935430
661: tickets: attempts=1 failures=0 p50_ms=53.006732 p99_ms=53.006732 max_ms=53.006732
661: poll: attempts=37 failures=0 p50_ms=4.068795 p99_ms=4.505453 max_ms=4.505453
661: attach: attempts=1 failures=0 p50_ms=41.462221 p99_ms=41.462221 max_ms=41.462221
661: handoff: attempts=1 failures=0 p50_ms=0.038886 p99_ms=0.038886 max_ms=0.038886
661: realm: attempts=1 failures=0 p50_ms=41.874962 p99_ms=41.874962 max_ms=41.874962
661: loadgen report
661: robots: 1  completed: 1
661: verify: attempts=1 failures=0 p50_ms=51.434053 p99_ms=51.434053 max_ms=51.434053
661: tickets: attempts=1 failures=0 p50_ms=52.012105 p99_ms=52.012105 max_ms=52.012105
661: poll: attempts=37 failures=0 p50_ms=4.045505 p99_ms=4.469295 max_ms=4.469295
661: attach: attempts=1 failures=0 p50_ms=41.494480 p99_ms=41.494480 max_ms=41.494480
661: handoff: attempts=1 failures=0 p50_ms=0.040538 p99_ms=0.040538 max_ms=0.040538
661: realm: attempts=1 failures=0 p50_ms=42.882312 p99_ms=42.882312 max_ms=42.882312
596: queue issuance write load: 886.132 committed numbers/s
596: queue issuance write load: 863.873 committed numbers/s
596: queue issuance write load: 896.434 committed numbers/s
663: acceptance_m2 robots=250 completed=250 skipped=0 attach_attempts=250 attach_failures=0 handoff_attempts=250 handoff_failures=0 fetch_count=250 fetch_retries=0 fetch_failure_rate=0
663: acceptance_m2 robots=250 completed=250 skipped=0 attach_attempts=250 attach_failures=0 handoff_attempts=250 handoff_failures=0 fetch_count=250 fetch_retries=0 fetch_failure_rate=0
663: acceptance_m2 robots=250 completed=250 skipped=0 attach_attempts=250 attach_failures=0 handoff_attempts=250 handoff_failures=0 fetch_count=250 fetch_retries=0 fetch_failure_rate=0
664: acceptance_m3 tickets_robots=10000 tickets_completed=10000 tickets_skipped=0 poll_robots=2000 poll_completed=2000 poll_skipped=0 poll_attempts=23544
17: acceptance_fault gateway_budget_removal elapsed_s=5 threshold_s=10 result=PASS
17: loadgen report
17: robots: 1  completed: 0
17: verify: attempts=1 failures=0 p50_ms=189.722522 p99_ms=189.722522 max_ms=189.722522
17: tickets: attempts=1 failures=0 p50_ms=144.537437 p99_ms=144.537437 max_ms=144.537437
17: poll: attempts=1 failures=0 p50_ms=9.980768 p99_ms=9.980768 max_ms=9.980768
17: attach: attempts=40 failures=40 p50_ms=0.000000 p99_ms=0.000000 max_ms=0.000000
17: loadgen report
17: robots: 1  completed: 1
17: verify: attempts=1 failures=0 p50_ms=159.100165 p99_ms=159.100165 max_ms=159.100165
17: tickets: attempts=1 failures=0 p50_ms=144.604427 p99_ms=144.604427 max_ms=144.604427
17: poll: attempts=38 failures=0 p50_ms=0.262492 p99_ms=49.277801 max_ms=49.277801
17: attach: attempts=1 failures=0 p50_ms=54.159329 p99_ms=54.159329 max_ms=54.159329
17: handoff: attempts=1 failures=0 p50_ms=95.616836 p99_ms=95.616836 max_ms=95.616836
17: realm: attempts=1 failures=0 p50_ms=44.336039 p99_ms=44.336039 max_ms=44.336039
17: acceptance_fault gateway_budget_restore elapsed_s=3 threshold_s=10 result=PASS
17: acceptance_fault realm_budget_removal elapsed_s=0 threshold_s=10 result=PASS
17: loadgen report
17: robots: 1  completed: 0
17: verify: attempts=1 failures=0 p50_ms=173.117165 p99_ms=173.117165 max_ms=173.117165
17: tickets: attempts=1 failures=0 p50_ms=144.566238 p99_ms=144.566238 max_ms=144.566238
17: poll: attempts=181 failures=45 p50_ms=0.225998 p99_ms=48.187763 max_ms=48.222535
17: loadgen report
17: robots: 1  completed: 1
17: verify: attempts=1 failures=0 p50_ms=186.738587 p99_ms=186.738587 max_ms=186.738587
17: tickets: attempts=1 failures=0 p50_ms=144.557187 p99_ms=144.557187 max_ms=144.557187
17: poll: attempts=17 failures=0 p50_ms=0.207216 p99_ms=50.192619 max_ms=50.192619
17: attach: attempts=1 failures=0 p50_ms=54.090717 p99_ms=54.090717 max_ms=54.090717
17: handoff: attempts=1 failures=0 p50_ms=95.710538 p99_ms=95.710538 max_ms=95.710538
17: realm: attempts=1 failures=0 p50_ms=45.556246 p99_ms=45.556246 max_ms=45.556246
17: acceptance_fault realm_budget_restore elapsed_s=2 threshold_s=10 result=PASS
17: loadgen report
17: robots: 1  completed: 1
17: verify: attempts=1 failures=0 p50_ms=152.018633 p99_ms=152.018633 max_ms=152.018633
17: tickets: attempts=1 failures=0 p50_ms=182.727519 p99_ms=182.727519 max_ms=182.727519
17: poll: attempts=16 failures=0 p50_ms=0.227612 p99_ms=48.604187 max_ms=48.604187
17: attach: attempts=1 failures=0 p50_ms=54.019364 p99_ms=54.019364 max_ms=54.019364
17: handoff: attempts=1 failures=0 p50_ms=95.648605 p99_ms=95.648605 max_ms=95.648605
17: realm: attempts=1 failures=0 p50_ms=45.447039 p99_ms=45.447039 max_ms=45.447039
17: acceptance_fault queue_released_number before=5 after=5 result=PASS
17: loadgen report
17: robots: 1  completed: 1
17: verify: attempts=1 failures=0 p50_ms=193.988302 p99_ms=193.988302 max_ms=193.988302
17: tickets: attempts=1 failures=0 p50_ms=140.713835 p99_ms=140.713835 max_ms=140.713835
17: poll: attempts=31 failures=0 p50_ms=0.250081 p99_ms=50.251382 max_ms=50.251382
17: attach: attempts=1 failures=0 p50_ms=45.573953 p99_ms=45.573953 max_ms=45.573953
17: handoff: attempts=1 failures=0 p50_ms=95.598537 p99_ms=95.598537 max_ms=95.598537
17: realm: attempts=1 failures=0 p50_ms=45.431423 p99_ms=45.431423 max_ms=45.431423
17: acceptance_fault queue_cold_restart elapsed_s=8 threshold_s=30 result=PASS
17: acceptance_fault etcd_outage_unready elapsed_s=1 threshold_s=10 result=PASS
17: loadgen report
17: robots: 1  completed: 0
17: verify: attempts=1 failures=0 p50_ms=159.450824 p99_ms=159.450824 max_ms=159.450824
17: tickets: attempts=1 failures=1 p50_ms=4109.253580 p99_ms=4109.253580 max_ms=4109.253580
17: acceptance_fault etcd_recovery elapsed_s=0 threshold_s=10 result=PASS
17: loadgen report
17: robots: 1  completed: 1
17: verify: attempts=1 failures=0 p50_ms=195.266724 p99_ms=195.266724 max_ms=195.266724
17: tickets: attempts=1 failures=0 p50_ms=145.727545 p99_ms=145.727545 max_ms=145.727545
17: poll: attempts=31 failures=0 p50_ms=0.227952 p99_ms=48.365386 max_ms=48.365386
17: attach: attempts=1 failures=0 p50_ms=41.291962 p99_ms=41.291962 max_ms=41.291962
17: handoff: attempts=1 failures=0 p50_ms=95.660125 p99_ms=95.660125 max_ms=95.660125
17: realm: attempts=1 failures=0 p50_ms=45.368976 p99_ms=45.368976 max_ms=45.368976
17: acceptance_fault queue_authoritative_recovery elapsed_s=3 threshold_s=30 result=PASS
```

## Limitations

- CI runs on one GitHub-hosted Ubuntu 24.04 machine; it does not prove cross-machine network or etcd TLS/authentication behavior.
- Accounts and characters come from MongoDB Player Data (ADR-0011): each case starts its own single-node `rs0` replica set on the runner, and Login Verifier authenticates, Gateway fetches and Realm rechecks against the same database. The replica set is local and unauthenticated, so this does not prove MongoDB TLS/authentication or multi-member failover. Loadgen capacity fixtures (thousands of robot accounts) use `credential_hash_cost = "minimum"`, so their Login Verify CPU cost is below a production Argon2 profile; single-account dev-services cases keep the default `interactive` cost.
- Results are not comparable with pre-#92 reports, whose Gateway fetch path was the `DelayedAccountFetchPort` controlled stub.
- CDN cache hit rate and the full 100k/1m production sizes require a separately approved dedicated environment; M5 remains separate.
