#include "realmmesh/test_support/mongod_process.hpp"
#include <chrono>
#include <fstream>
#include <iostream>

int main() {
    using clock = std::chrono::steady_clock;
    auto start = clock::now();
    realm::test_support::MongodProcess process;
    auto ready = clock::now();
    auto directory = std::filesystem::temp_directory_path();
    std::ifstream server_log;
    const auto prefix = "realmmesh-mongod-" + std::to_string(::getpid()) + "-";
    for (const auto& entry : std::filesystem::directory_iterator(directory)) {
        if (entry.path().filename().string().starts_with(prefix)) {
            server_log.open(entry.path() / "mongod.log");
            break;
        }
    }
    process.stop();
    auto stopped = clock::now();
    std::cout << "{\"ready_s\":" << std::chrono::duration<double>(ready-start).count()
              << ",\"stop_s\":" << std::chrono::duration<double>(stopped-ready).count() << "}\n";
    if (const char* path = std::getenv("REALMMESH_PROFILE_SERVER_LOG")) {
        std::ofstream saved(path);
        saved << server_log.rdbuf();
    }
}
