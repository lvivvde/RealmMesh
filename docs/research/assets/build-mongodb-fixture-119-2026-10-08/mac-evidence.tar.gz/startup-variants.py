#!/usr/bin/env python3
"""Diagnostic only: pair real isolated mongod startup configurations."""
import json,signal,socket,subprocess,time,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent
MONGOD='/opt/homebrew/bin/mongod';MONGOSH='/opt/homebrew/bin/mongosh'
HELPER=ROOT/'after/build/dev-ninja/tests/cpp/support/realmmesh_mongodb_fixture'
variants={'default':[],'kill':[]}
rows=[]
for group in range(1,6):
 for name in (list(variants) if group%2 else list(reversed(variants))):
  directory=ROOT/'startup-variants'/f'{group}-{name}';directory.mkdir(parents=True,exist_ok=False)
  with socket.socket() as listener:listener.bind(('127.0.0.1',0));port=listener.getsockname()[1]
  command=[MONGOD,'--replSet','rs0','--bind_ip','127.0.0.1','--port',str(port),'--dbpath',str(directory),'--logpath',str(directory/'mongod.jsonl'),'--nounixsocket','--wiredTigerCacheSizeGB','0.25',*variants[name]]
  start=time.monotonic();server=subprocess.Popen(command,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  try:
   while True:
    if server.poll() is not None:raise RuntimeError('mongod startup failed')
    if time.monotonic()-start>10:raise RuntimeError('mongod port deadline')
    try:
     with socket.create_connection(('127.0.0.1',port),timeout=.1):break
    except OSError:time.sleep(.01)
   port_s=time.monotonic()-start;begin=time.monotonic()
   initialized=subprocess.run([str(HELPER),f'127.0.0.1:{port}','30000'],capture_output=True,text=True,timeout=35)
   ready_s=time.monotonic()-start;initializer_s=time.monotonic()-begin
   if initialized.returncode:raise RuntimeError(initialized.stderr)
   observed=subprocess.check_output([MONGOSH,f'mongodb://127.0.0.1:{port}/?directConnection=true','--quiet','--norc','--eval',"const h=db.hello();print(h.setName+':'+h.isWritablePrimary)"],text=True,timeout=10).strip()
   assert observed=='rs0:true'
   begin=time.monotonic()
   if name=='kill':server.kill()
   else:server.terminate()
   server.wait(timeout=2);stop_s=time.monotonic()-begin
   row={'group':group,'variant':name,'command':command,'port_s':port_s,'initializer_s':initializer_s,'ready_s':ready_s,'stop_s':stop_s,'lifecycle_s':ready_s+stop_s,'observed':observed,'shutdown_signal':('SIGKILL' if name=='kill' else 'SIGTERM'),'mongod_exit':server.returncode,'exit':initialized.returncode}
   rows.append(row);(ROOT/'startup-variants.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
  finally:
   if server.poll() is None:
    server.send_signal(signal.SIGCONT);server.terminate()
    try:server.wait(timeout=2)
    except subprocess.TimeoutExpired:server.kill();server.wait()

   for path in directory.iterdir():
    if path.name!='mongod.jsonl':
     if path.is_dir():shutil.rmtree(path)
     else:path.unlink()
