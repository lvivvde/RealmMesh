import json,os,subprocess,time
from pathlib import Path
r=Path('/private/tmp/realmmesh-119-mongodb-next')
env=os.environ.copy()
env.update(TMPDIR=str(r/'mac-tmp'),REALMMESH_MONGOSH_BINARY=str(r/'native-init-probe'),REALMMESH_PROBE_MONGOSH_FALLBACK=str(r/'mongosh-probe.py'),REALMMESH_PROBE_REAL_MONGOSH='/opt/homebrew/bin/mongosh',REALMMESH_PROBE_MONGOSH_LOG=str(r/'mac-native-fallback-events.jsonl'))
cmd=['ctest','--test-dir','/Users/edwin/Projects/RealmMesh/build/dev-ninja','-j','1','--output-on-failure']
t=time.monotonic_ns()
with (r/'mac-native-prototype-full.log').open('w') as f:status=subprocess.call(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
(r/'mac-native-prototype-full.json').write_text(json.dumps(dict(command=cmd,exit=status,wall_s=(time.monotonic_ns()-t)/1e9,instrumented=True),indent=2)+'\n')
print('diagnostic finished',status,flush=True)
raise SystemExit(status)
