set_property(GLOBAL PROPERTY RULE_LAUNCH_COMPILE "\"/private/tmp/realmmesh-119-mongodb-next/launcher\"")
